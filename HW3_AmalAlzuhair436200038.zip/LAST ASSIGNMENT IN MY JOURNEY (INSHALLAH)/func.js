function f1 (){
	const FullName = localStorage.getItem('fname');
	//alert('Hello', FullName);
}
	
