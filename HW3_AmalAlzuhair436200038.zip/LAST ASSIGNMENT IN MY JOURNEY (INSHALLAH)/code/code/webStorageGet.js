function getUserData() {
    
    if ('localStorage' in window && window['localStorage'] !== null) {
				
		const FullName = localStorage.getItem('fname');
		//const gender = localStorage.getItem('gender');


		const node = document.createElement("p");
		const textnode = document.createTextNode(petname + " " + gender);
		node.appendChild(textnode);
		document.querySelector("#result").appendChild(node);

	} else {
		alert('Cannot store user preferences as your browser do not support local storage');
	}
}


getUserData();

