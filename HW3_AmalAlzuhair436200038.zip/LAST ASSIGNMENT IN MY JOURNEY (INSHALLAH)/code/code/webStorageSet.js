
	
function storeValues() {
    
    if ('localStorage' in window && window['localStorage'] !== null) {
		const name = document.querySelector('#petname').value;
		//const gender = document.querySelector('input[name="gender"]:checked').value;
            //Radiobutton
		localStorage.setItem('fname', fname);
		//localStorage.setItem('gender', gender);

	} else {
		alert('Cannot store user preferences as your browser do not support local storage');
	}
}
const submitBtn = document.querySelector('#sBtn');
submitBtn.addEventListener('click', storeValues);