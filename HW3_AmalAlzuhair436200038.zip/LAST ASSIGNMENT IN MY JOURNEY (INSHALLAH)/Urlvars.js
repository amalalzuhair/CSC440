function getUrlVars() {
    //var vars = {};
	window.location.replace("about.html");
  // var parts = window.location.href.replace(about.html, function(m,key,value) {
      //  vars[key] = value;
    //});
   // return vars; 
alert('hi');
}


var Fullname = getUrlVars()["fname"];
//var likeToSee = getUrlVars()["likeToSee"];

var node = document.createElement("p");
var textnode = document.createTextNode(Fullname);
node.appendChild(textnode);
document.querySelector("#result").appendChild(node);
